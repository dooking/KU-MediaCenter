const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth2').Strategy;
const UserService = require('../service/user-service')

passport.serializeUser(function (user, done) {
    done(null, user);
});
passport.deserializeUser(function (user, done) {
    done(null, user);
});

passport.use(new GoogleStrategy(
    {
        clientID: process.env.GOOGLE_CLIENT_ID,
        clientSecret: process.env.GOOGLE_SECRET,
        callbackURL: 'http://127.0.0.1:3000/user/login/callback',
        passReqToCallback: true
    }, async function (request, accessToken, refreshToken, profile, done) {
        try {
            const {
                _json: { sub, name, domain },
            } = profile

            if (domain !== process.env.EMAIL) {
                return done(null, false, { message: '학교 이메일이 아닙니다' })
            }
            const userInfo = name.split('[')
            const userName = userInfo[0]
            const major = '[' + userInfo[1]

            const [findError, user] = await UserService.findUser(sub)
            if (findError) {
                return done(null, false, { message: 'DB Error' })
            }
            if (user) {
                return done(null, user)
            }
            const [insertError, addNewUser] = await UserService.insertUser({
                identity: sub,
                name: userName,
                major: major,
            })
            if (insertError || !addNewUser) {
                return done(null, false, { message: 'DB Error' })
            }
            return done(null, addNewUser)
        } catch (err) {
            return done(null, false, { msg: '올바르지 않은 인증정보 입니다.' })
        }
    }
));

module.exports = passport;